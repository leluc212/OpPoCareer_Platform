/**
 * Lambda Function: Pre Sign-up & Post Confirmation (ES Module)
 * Triggers: Pre sign-up + Post confirmation
 * 
 * Pre Sign-up: Auto-verify email (but NOT auto-confirm user)
 * Post Confirmation: Add user to group based on clientMetadata.role
 */

import { CognitoIdentityProviderClient, AdminAddUserToGroupCommand } from "@aws-sdk/client-cognito-identity-provider";

const client = new CognitoIdentityProviderClient({ region: process.env.AWS_REGION || "ap-southeast-1" });

export const handler = async (event) => {
    console.log('========================================');
    console.log('Lambda Trigger:', event.triggerSource);
    console.log('Event:', JSON.stringify(event, null, 2));
    console.log('========================================');
    
    // PRE SIGN-UP: Save role from clientMetadata to user attributes
    if (event.triggerSource === 'PreSignUp_SignUp') {
        console.log('PRE SIGN-UP: Processing sign up...');
        
        // Get role from clientMetadata
        let role = null;
        if (event.request && event.request.clientMetadata) {
            role = event.request.clientMetadata.role;
            console.log('Role from clientMetadata:', role);
        }
        
        // Save role to user attributes so it's available in PostConfirmation
        if (role) {
            // Use custom:role attribute to store the role
            event.response.autoVerifyEmail = false;
            event.response.autoConfirmUser = false;
            
            // Note: We cannot directly set custom attributes in PreSignUp
            // They must be set during signUp call from the client
            console.log('Role will be retrieved from user attributes in PostConfirmation');
        }
        
        console.log('✅ User must confirm with OTP code sent to email');
        return event;
    }
    
    // POST CONFIRMATION: Add user to group after they confirm with OTP
    if (event.triggerSource === 'PostConfirmation_ConfirmSignUp') {
        console.log('POST CONFIRMATION: Adding user to group...');
        
        const userPoolId = event.userPoolId;
        const username = event.userName;
        
        // Get role from user attributes (profile attribute)
        let role = null;
        if (event.request && event.request.userAttributes) {
            // Check profile attribute first (where we store the role)
            role = event.request.userAttributes['profile'];
            console.log('Role from profile attribute:', role);
            
            // Fallback to custom:role if exists
            if (!role) {
                role = event.request.userAttributes['custom:role'];
                console.log('Role from custom:role attribute:', role);
            }
        }
        
        // Default to Candidate if no role found
        if (!role) {
            role = 'Candidate';
            console.log('No role found, defaulting to Candidate');
        }
        
        // Determine group name
        const groupName = (role === 'Employer' || role === 'employer') ? 'Employer' : 'Candidate';
        console.log(`Adding user "${username}" to group "${groupName}"`);
        console.log('User attributes:', JSON.stringify(event.request.userAttributes, null, 2));
        
        try {
            const command = new AdminAddUserToGroupCommand({
                UserPoolId: userPoolId,
                Username: username,
                GroupName: groupName
            });
            
            const response = await client.send(command);
            console.log('✅ SUCCESS: User added to group');
            console.log('Response:', JSON.stringify(response, null, 2));
            
        } catch (error) {
            console.error('❌ ERROR: Failed to add user to group');
            console.error('Error:', JSON.stringify(error, null, 2));
            // Don't throw error to avoid blocking user confirmation
        }
        
        console.log('========================================');
        console.log('Post Confirmation Completed');
        console.log('========================================');
        
        return event;
    }
    
    // Other triggers
    console.log('Other trigger, returning event as-is');
    return event;
};
