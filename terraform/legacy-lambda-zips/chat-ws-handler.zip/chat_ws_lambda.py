import json
import os
import boto3
from boto3.dynamodb.conditions import Key
from datetime import datetime, timezone
from auth_utils import verify_token

# DynamoDB tables
CONNECTIONS_TABLE = os.environ.get('CHAT_CONNECTIONS_TABLE', 'ChatConnections')
MESSAGES_TABLE = os.environ.get('CHAT_MESSAGES_TABLE', 'ChatMessages')
CONVERSATIONS_TABLE = os.environ.get('CHAT_CONVERSATIONS_TABLE', 'ChatConversations')
AWS_REGION = os.environ.get('AWS_REGION', 'ap-southeast-1')

dynamodb = boto3.resource('dynamodb', region_name=AWS_REGION)
connections_table = dynamodb.Table(CONNECTIONS_TABLE)
messages_table = dynamodb.Table(MESSAGES_TABLE)
conversations_table = dynamodb.Table(CONVERSATIONS_TABLE)


def _update_conversation_on_message(conversation_id, message_id, text, sender_id, sender_role, recipient_role):
    now = datetime.now(timezone.utc).isoformat()
    expr_names = {
        '#lm': 'lastMessage',
        '#lma': 'lastMessageAt',
        '#lsid': 'lastSenderId',
        '#lsr': 'lastSenderRole',
        '#lmid': 'lastMessageId',
        '#ua': 'updatedAt',
        '#ca': 'createdAt'
    }
    expr_values = {
        ':m': text,
        ':t': now,
        ':sid': sender_id or '',
        ':srole': sender_role or '',
        ':mid': message_id
    }

    update_expr = (
        'SET #ua = :t, #lma = :t, #lm = :m, #lsid = :sid, #lsr = :srole, '
        '#lmid = :mid, #ca = if_not_exists(#ca, :t)'
    )

    conversations_table.update_item(
        Key={'conversationId': conversation_id},
        UpdateExpression=update_expr,
        ExpressionAttributeNames=expr_names,
        ExpressionAttributeValues=expr_values
    )

    if recipient_role:
        try:
            conversations_table.update_item(
                Key={'conversationId': conversation_id},
                UpdateExpression='SET #uc = if_not_exists(#uc, :empty)',
                ExpressionAttributeNames={'#uc': 'unreadCounts'},
                ExpressionAttributeValues={':empty': {}}
            )

            conversations_table.update_item(
                Key={'conversationId': conversation_id},
                UpdateExpression='SET #uc.#rr = if_not_exists(#uc.#rr, :zero) + :one',
                ExpressionAttributeNames={'#uc': 'unreadCounts', '#rr': recipient_role},
                ExpressionAttributeValues={':zero': 0, ':one': 1}
            )
        except Exception as error:
            print('Failed to update unread counts:', error)


def lambda_handler(event, context):
    # API Gateway v2 WebSocket events include eventType
    event_type = event.get('requestContext', {}).get('eventType')
    connection_id = event.get('requestContext', {}).get('connectionId')
    domain_name = event.get('requestContext', {}).get('domainName')
    stage = event.get('requestContext', {}).get('stage')

    # Build management API client for sending messages
    endpoint_url = f"https://{domain_name}/{stage}"
    apigw = boto3.client('apigatewaymanagementapi', endpoint_url=endpoint_url, region_name=AWS_REGION)

    if event_type == 'CONNECT':
        # Store connection with optional conversationId / user info from query params
        qs = event.get('queryStringParameters') or {}
        conversation_id = qs.get('conversationId')
        user_id = qs.get('userId')
        role = qs.get('role')
        token = qs.get('token')

        if not token:
            return {'statusCode': 401, 'body': 'Missing token'}

        claims = verify_token(token)
        if not claims:
            return {'statusCode': 401, 'body': 'Invalid token'}

        user_id = claims.get('sub') or user_id

        item = {
            'connectionId': connection_id,
            'conversationId': conversation_id or '',
            'userId': user_id or '',
            'role': role or '',
            'connectedAt': datetime.now(timezone.utc).isoformat()
        }
        connections_table.put_item(Item=item)
        return {'statusCode': 200, 'body': 'Connected'}

    if event_type == 'DISCONNECT':
        # Remove connection
        try:
            connections_table.delete_item(Key={'connectionId': connection_id})
        except Exception:
            pass
        return {'statusCode': 200, 'body': 'Disconnected'}

    # MESSAGE
    try:
        body = event.get('body') or '{}'
        data = json.loads(body)
    except Exception:
        return {'statusCode': 400, 'body': 'Invalid JSON'}

    action = data.get('action') or data.get('type') or 'message'

    if action in ('sendMessage', 'message'):
        convo_id = data.get('conversationId')
        text = data.get('text') or data.get('message') or ''
        sender_id = data.get('senderId') or ''
        sender_role = data.get('senderRole') or ''
        recipient_id = data.get('recipientId') or ''
        recipient_role = data.get('recipientRole') or ''

        # Persist message in messages table
        msg_item = {
            'conversationId': convo_id,
            'createdAt': datetime.now(timezone.utc).isoformat(),
            'messageId': data.get('messageId') or f"msg-{int(datetime.now(timezone.utc).timestamp()*1000)}",
            'senderId': sender_id,
            'senderRole': sender_role,
            'recipientId': recipient_id,
            'recipientRole': recipient_role,
            'text': text,
            'status': 'active'
        }
        if data.get('replyToMessageId'):
            msg_item['replyToMessageId'] = data.get('replyToMessageId')
            msg_item['replyToText'] = data.get('replyToText') or ''
            msg_item['replyToSenderRole'] = data.get('replyToSenderRole') or ''
        try:
            messages_table.put_item(Item=msg_item)
        except Exception as e:
            print('Failed to save message:', e)

        # Broadcast to all connections in the conversation (query ConversationIndex on connections table)
        try:
            # Query connections by conversationId using GSI ConversationIndex
            resp = connections_table.query(
                IndexName='ConversationIndex',
                KeyConditionExpression=Key('conversationId').eq(convo_id)
            )
            items = resp.get('Items', [])
        except Exception:
            # Fallback: scan (less efficient)
            resp = connections_table.scan()
            items = [it for it in resp.get('Items', []) if it.get('conversationId') == convo_id]

        _update_conversation_on_message(
            convo_id,
            msg_item['messageId'],
            text,
            sender_id,
            sender_role,
            recipient_role
        )

        payload = {
            'type': 'message',
            'conversationId': convo_id,
            'messageId': msg_item['messageId'],
            'senderId': sender_id,
            'senderRole': sender_role,
            'text': text,
            'createdAt': msg_item['createdAt'],
            'status': msg_item['status'],
            'replyToMessageId': msg_item.get('replyToMessageId'),
            'replyToText': msg_item.get('replyToText'),
            'replyToSenderRole': msg_item.get('replyToSenderRole')
        }

        for conn in items:
            target = conn.get('connectionId')
            try:
                apigw.post_to_connection(ConnectionId=target, Data=json.dumps(payload).encode('utf-8'))
            except apigw.exceptions.GoneException:
                # Clean up stale connection
                try:
                    connections_table.delete_item(Key={'connectionId': target})
                except Exception:
                    pass
            except Exception as e:
                print('Failed to post to connection', target, e)

        return {'statusCode': 200, 'body': json.dumps({'success': True, 'messageId': msg_item['messageId']})}

    return {'statusCode': 400, 'body': 'Unsupported action'}
