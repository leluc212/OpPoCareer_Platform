import json
import os
import time
import urllib.request

from jose import jwt

USER_POOL_ID = os.environ.get('USER_POOL_ID')
AWS_REGION = os.environ.get('AWS_REGION', 'ap-southeast-1')

_JWKS_CACHE = {
  'keys': None,
  'expiresAt': 0
}


def _fetch_jwks():
  if not USER_POOL_ID:
    raise ValueError('USER_POOL_ID is not configured')

  now = int(time.time())
  if _JWKS_CACHE['keys'] and now < _JWKS_CACHE['expiresAt']:
    return _JWKS_CACHE['keys']

  jwks_url = f"https://cognito-idp.{AWS_REGION}.amazonaws.com/{USER_POOL_ID}/.well-known/jwks.json"
  with urllib.request.urlopen(jwks_url) as response:
    payload = response.read().decode('utf-8')
    jwks = json.loads(payload)

  _JWKS_CACHE['keys'] = jwks.get('keys', [])
  _JWKS_CACHE['expiresAt'] = now + 3600
  return _JWKS_CACHE['keys']


def verify_token(token):
  if not token:
    return None

  try:
    keys = _fetch_jwks()
    unverified = jwt.get_unverified_header(token)
    key = next((k for k in keys if k.get('kid') == unverified.get('kid')), None)
    if not key:
      return None

    claims = jwt.decode(
      token,
      key,
      algorithms=['RS256'],
      options={'verify_aud': False}
    )
    return claims
  except Exception:
    return None
