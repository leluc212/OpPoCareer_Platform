import json
import boto3
import base64
import uuid
from datetime import datetime
from decimal import Decimal

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('CandidateProfiles')

BUCKET_NAME = 'opporeview-cv-storage'
ALLOWED_EXTENSIONS = ['.pdf', '.doc', '.docx']
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB
MAX_CV_COUNT = 3  # Maximum 3 CVs per user

def lambda_handler(event, context):
    print(f"Event: {json.dumps(event)}")
    
    # Common headers for all responses including CORS
    response_headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Credentials': 'true'
    }

    def create_response(status_code, body):
        return {
            'statusCode': status_code,
            'headers': response_headers,
            'body': json.dumps(body)
        }

    try:
        http_method = event.get('httpMethod', event.get('requestContext', {}).get('http', {}).get('method', ''))
        path = event.get('rawPath', event.get('path', ''))
        
        print(f"Executing method: {http_method}, Path: {path}")

        if http_method == 'OPTIONS':
            return create_response(200, {'message': 'OK'})

        # Upload CV
        elif http_method == 'POST' and path.endswith('/upload'):
            body = json.loads(event.get('body', '{}'))
            return upload_cv(body, create_response)

        # Get CV Info (List)
        elif http_method == 'GET' and '/cv/' in path:
            user_id = path.split('/cv/')[-1].replace('/prod', '').strip('/')
            return get_cv_list(user_id, create_response)

        # Delete CV
        elif http_method == 'DELETE' and '/cv/' in path:
            parts = path.split('/cv/')[-1].replace('/prod', '').strip('/').split('/')
            user_id = parts[0]
            cv_id = parts[1] if len(parts) > 1 else None
            
            if cv_id:
                return delete_specific_cv(user_id, cv_id, create_response)
            else:
                return delete_all_cvs(user_id, create_response)
        
        else:
            return create_response(404, {'error': f'Route not found: {http_method} {path}'})

    except Exception as e:
        print(f"Error in lambda_handler: {str(e)}")
        return create_response(500, {'error': str(e)})

def upload_cv(body, create_response):
    user_id = body.get('userId')
    file_name = body.get('fileName')
    file_content = body.get('fileContent')
    file_type = body.get('fileType', 'application/pdf')
    
    if not all([user_id, file_name, file_content]):
        return create_response(400, {'error': 'Missing required fields: userId, fileName, fileContent'})
    
    file_ext = '.' + file_name.split('.')[-1].lower()
    if file_ext not in ALLOWED_EXTENSIONS:
        return create_response(400, {'error': f'Invalid file type. Allowed: {", ".join(ALLOWED_EXTENSIONS)}'})
    
    try:
        file_data = base64.b64decode(file_content)
    except:
        return create_response(400, {'error': 'Invalid base64 content'})
    
    if len(file_data) > MAX_FILE_SIZE:
        return create_response(400, {'error': f'File too large. Max size: {MAX_FILE_SIZE / 1024 / 1024}MB'})
    
    try:
        response = table.get_item(Key={'userId': user_id})
        item = response.get('Item', {})
        cv_list = item.get('cvList', [])
        if len(cv_list) >= MAX_CV_COUNT:
            return create_response(400, {'error': f'Maximum {MAX_CV_COUNT} CVs allowed.'})
    except:
        cv_list = []
    
    cv_id = str(uuid.uuid4())
    s3_key = f"cvs/{user_id}/{cv_id}_{file_name}"
    
    try:
        s3_client.put_object(Bucket=BUCKET_NAME, Key=s3_key, Body=file_data, ContentType=file_type)
        new_cv = {'id': cv_id, 'cvFileName': file_name, 'cvS3Key': s3_key, 'cvUploadDate': datetime.now().isoformat()}
        cv_list.append(new_cv)
        table.update_item(
            Key={'userId': user_id},
            UpdateExpression='SET cvList = :list, updatedAt = :updated',
            ExpressionAttributeValues={':list': cv_list, ':updated': datetime.now().isoformat()}
        )
        return create_response(200, {'message': 'Upload successful', 'cv': new_cv})
    except Exception as e:
        return create_response(500, {'error': str(e)})

def get_cv_list(user_id, create_response):
    try:
        response = table.get_item(Key={'userId': user_id})
        if 'Item' not in response: return create_response(404, {'error': 'User not found'})
        return create_response(200, {'cvList': response['Item'].get('cvList', [])})
    except Exception as e:
        return create_response(500, {'error': str(e)})

def delete_specific_cv(user_id, cv_id, create_response):
    try:
        response = table.get_item(Key={'userId': user_id})
        if 'Item' not in response: return create_response(404, {'error': 'User not found'})
        cv_list = response['Item'].get('cvList', [])
        cv_to_delete = next((cv for cv in cv_list if cv['id'] == cv_id), None)
        if not cv_to_delete: return create_response(404, {'error': 'CV not found'})
        
        if cv_to_delete.get('cvS3Key'):
            s3_client.delete_object(Bucket=BUCKET_NAME, Key=cv_to_delete['cvS3Key'])
            
        updated_list = [cv for cv in cv_list if cv['id'] != cv_id]
        table.update_item(
            Key={'userId': user_id},
            UpdateExpression='SET cvList = :list, updatedAt = :updated',
            ExpressionAttributeValues={':list': updated_list, ':updated': datetime.now().isoformat()}
        )
        return create_response(200, {'message': 'Deleted successfully'})
    except Exception as e:
        return create_response(500, {'error': str(e)})

def delete_all_cvs(user_id, create_response):
    try:
        table.update_item(
            Key={'userId': user_id},
            UpdateExpression='SET cvList = :list',
            ExpressionAttributeValues={':list': []}
        )
        return create_response(200, {'message': 'All CVs deleted'})
    except Exception as e:
        return create_response(500, {'error': str(e)})
