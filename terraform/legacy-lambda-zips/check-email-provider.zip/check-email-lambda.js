'use strict';
/**
 * check-email-provider Lambda
 *
 * GET  /auth/check-email?email=<email>
 * POST /auth/google-otp/request
 * POST /auth/google-otp/verify
 */

const crypto = require('crypto');
const {
  AdminSetUserPasswordCommand,
  CognitoIdentityProviderClient,
  ListUsersCommand,
} = require('@aws-sdk/client-cognito-identity-provider');
const {
  DeleteItemCommand,
  DynamoDBClient,
  GetItemCommand,
  PutItemCommand,
} = require('@aws-sdk/client-dynamodb');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');

const REGION = process.env.AWS_REGION || 'ap-southeast-1';
const USER_POOL_ID = process.env.USER_POOL_ID || 'ap-southeast-1_ShCajkmJd';
const OTP_TABLE_NAME = process.env.AUTH_OTP_TABLE_NAME || 'OppoAuthOtp';
const OTP_SOURCE_EMAIL =
  process.env.AUTH_OTP_SOURCE_EMAIL || 'no-reply@oppocareer.com';
const OTP_TTL_SECONDS = 10 * 60;

const cognitoClient = new CognitoIdentityProviderClient({ region: REGION });
const dynamoClient = new DynamoDBClient({ region: REGION });
const sesClient = new SESClient({ region: REGION });

const ALLOWED_ORIGINS = [
  'https://hd-2004.github.io',
  'https://hd-2004.github.io/OppoApp',
  'https://hd-2004.github.io/OppoApp/',
  'https://oppocareer.com',
  'https://www.oppocareer.com',
];

function isAllowedOrigin(origin) {
  return (
    ALLOWED_ORIGINS.includes(origin) ||
    /^http:\/\/localhost:\d+$/.test(origin) ||
    /^http:\/\/127\.0\.0\.1:\d+$/.test(origin)
  );
}

function getCorsHeaders(requestOrigin) {
  const origin = isAllowedOrigin(requestOrigin)
    ? requestOrigin
    : 'https://oppocareer.com';
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,Accept',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Content-Type': 'application/json',
    Vary: 'Origin',
  };
}

function res(statusCode, body, corsHeaders) {
  return {
    statusCode,
    headers: corsHeaders,
    body: JSON.stringify(body),
  };
}

function detail(statusCode, message, corsHeaders) {
  return res(statusCode, { detail: message }, corsHeaders);
}

function normalizeEmail(email) {
  return String(email || '').trim().toLowerCase();
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function parseBody(event) {
  if (!event.body) return {};
  const raw = event.isBase64Encoded
    ? Buffer.from(event.body, 'base64').toString('utf8')
    : event.body;
  return JSON.parse(raw);
}

function providerFromUser(user) {
  const username = String(user.Username || '');
  if (username.toLowerCase().startsWith('google_')) {
    return 'google';
  }

  const identities = (user.Attributes || []).find(
    (item) => item.Name === 'identities',
  )?.Value;
  if (!identities) return 'native';

  try {
    const parsed = JSON.parse(identities);
    return parsed.some(
      (item) => String(item.providerName || '').toLowerCase() === 'google',
    )
      ? 'google'
      : 'native';
  } catch (_) {
    return 'native';
  }
}

async function findUsersByEmail(email) {
  const response = await cognitoClient.send(
    new ListUsersCommand({
      UserPoolId: USER_POOL_ID,
      Filter: `email = "${email}"`,
      Limit: 5,
    }),
  );
  return response.Users || [];
}

async function findGoogleAccount(email) {
  const users = await findUsersByEmail(email);
  const googleUser = users.find((user) => providerFromUser(user) === 'google');
  if (!googleUser) {
    if (users.length > 0) {
      throw Object.assign(new Error('not_google_account'), {
        code: 'not_google_account',
      });
    }
    throw Object.assign(new Error('not_found'), { code: 'not_found' });
  }
  return googleUser;
}

function otpHash(code) {
  return crypto.createHash('sha256').update(String(code).trim()).digest('hex');
}

function generateOtp() {
  return String(crypto.randomInt(0, 1000000)).padStart(6, '0');
}

async function saveOtp(email, code) {
  const expiresAtEpoch = Math.floor(Date.now() / 1000) + OTP_TTL_SECONDS;
  await dynamoClient.send(
    new PutItemCommand({
      TableName: OTP_TABLE_NAME,
      Item: {
        email: { S: email },
        code_hash: { S: otpHash(code) },
        expires_at_epoch: { N: String(expiresAtEpoch) },
      },
    }),
  );
}

async function consumeOtp(email, code) {
  const nowEpoch = Math.floor(Date.now() / 1000);
  try {
    await dynamoClient.send(
      new DeleteItemCommand({
        TableName: OTP_TABLE_NAME,
        Key: { email: { S: email } },
        ConditionExpression: 'code_hash = :code_hash AND expires_at_epoch > :now',
        ExpressionAttributeValues: {
          ':code_hash': { S: otpHash(code) },
          ':now': { N: String(nowEpoch) },
        },
      }),
    );
    return true;
  } catch (error) {
    if (error.name !== 'ConditionalCheckFailedException') {
      throw error;
    }
  }

  const existing = await dynamoClient.send(
    new GetItemCommand({
      TableName: OTP_TABLE_NAME,
      Key: { email: { S: email } },
    }),
  );
  const expiresAt = Number(existing.Item?.expires_at_epoch?.N || 0);
  if (existing.Item && expiresAt <= nowEpoch) {
    await dynamoClient.send(
      new DeleteItemCommand({
        TableName: OTP_TABLE_NAME,
        Key: { email: { S: email } },
      }),
    );
    throw Object.assign(new Error('expired_code'), { code: 'expired_code' });
  }
  return false;
}

async function sendOtpEmail(email, otp) {
  await sesClient.send(
    new SendEmailCommand({
      Source: OTP_SOURCE_EMAIL,
      Destination: { ToAddresses: [email] },
      Message: {
        Subject: { Data: 'Ma OTP dang nhap Op Po', Charset: 'UTF-8' },
        Body: {
          Text: {
            Data: `Ma OTP cua ban la: ${otp}\nMa co hieu luc trong 10 phut.`,
            Charset: 'UTF-8',
          },
        },
      },
    }),
  );
}

async function handleCheckEmail(event, corsHeaders) {
  const qs = event.queryStringParameters || {};
  const email = normalizeEmail(qs.email);

  if (!email) return res(400, { error: 'email query param is required' }, corsHeaders);
  if (!isValidEmail(email)) return res(400, { error: 'Invalid email format' }, corsHeaders);

  const users = await findUsersByEmail(email);
  if (users.length === 0) return res(200, { exists: false }, corsHeaders);

  const hasNative = users.some((user) => providerFromUser(user) === 'native');
  return res(
    200,
    { exists: true, provider: hasNative ? 'native' : 'google' },
    corsHeaders,
  );
}

async function handleRequestOtp(event, corsHeaders) {
  const body = parseBody(event);
  const email = normalizeEmail(body.email);

  if (!isValidEmail(email)) return detail(400, 'Email không hợp lệ.', corsHeaders);

  await findGoogleAccount(email);
  const otp = generateOtp();
  await saveOtp(email, otp);
  await sendOtpEmail(email, otp);
  return res(200, { delivery: 'email' }, corsHeaders);
}

async function handleVerifyOtp(event, corsHeaders) {
  const body = parseBody(event);
  const email = normalizeEmail(body.email);
  const code = String(body.code || '').trim();
  const newPassword = String(body.new_password || '');

  if (!isValidEmail(email)) return detail(400, 'Email không hợp lệ.', corsHeaders);
  if (!/^\d{6}$/.test(code)) return detail(400, 'Mã OTP không đúng.', corsHeaders);
  if (newPassword.length < 8) {
    return detail(400, 'Mật khẩu cần ít nhất 8 ký tự.', corsHeaders);
  }

  const googleUser = await findGoogleAccount(email);
  const consumed = await consumeOtp(email, code);
  if (!consumed) return detail(400, 'Mã OTP không đúng.', corsHeaders);

  await cognitoClient.send(
    new AdminSetUserPasswordCommand({
      UserPoolId: USER_POOL_ID,
      Username: googleUser.Username,
      Password: newPassword,
      Permanent: true,
    }),
  );
  return res(200, { ok: true }, corsHeaders);
}

function errorToResponse(error, corsHeaders) {
  if (error.code === 'not_found') {
    return detail(404, 'Không tìm thấy tài khoản.', corsHeaders);
  }
  if (error.code === 'not_google_account') {
    return detail(400, 'Tài khoản này không phải tài khoản Google.', corsHeaders);
  }
  if (error.code === 'expired_code') {
    return detail(400, 'Mã OTP đã hết hạn.', corsHeaders);
  }
  if (error.name === 'InvalidPasswordException') {
    return detail(400, 'Mật khẩu chưa đúng yêu cầu bảo mật.', corsHeaders);
  }
  console.error('check-email-provider error:', error);
  return detail(500, 'Không thể gửi hoặc xác minh OTP.', corsHeaders);
}

exports.handler = async (event) => {
  const httpCtx = event.requestContext?.http || {};
  const method = (event.httpMethod || httpCtx.method || 'GET').toUpperCase();
  const path = event.rawPath || event.path || httpCtx.path || '/';
  const headers = event.headers || {};
  const requestOrigin = headers.origin || headers.Origin || '';
  const corsHeaders = getCorsHeaders(requestOrigin);

  if (method === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders, body: '' };
  }

  try {
    if (method === 'GET' && path === '/auth/check-email') {
      return await handleCheckEmail(event, corsHeaders);
    }
    if (method === 'POST' && path === '/auth/google-otp/request') {
      return await handleRequestOtp(event, corsHeaders);
    }
    if (method === 'POST' && path === '/auth/google-otp/verify') {
      return await handleVerifyOtp(event, corsHeaders);
    }
    return res(404, { error: 'Not found' }, corsHeaders);
  } catch (error) {
    return errorToResponse(error, corsHeaders);
  }
};
