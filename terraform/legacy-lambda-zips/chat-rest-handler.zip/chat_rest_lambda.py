import json
import os
import boto3
from decimal import Decimal
from boto3.dynamodb.conditions import Key
from datetime import datetime, timezone
from auth_utils import verify_token

CONVERSATIONS_TABLE = os.environ.get('CHAT_CONVERSATIONS_TABLE', 'ChatConversations')
MESSAGES_TABLE = os.environ.get('CHAT_MESSAGES_TABLE', 'ChatMessages')
CONNECTIONS_TABLE = os.environ.get('CHAT_CONNECTIONS_TABLE', 'ChatConnections')
AWS_REGION = os.environ.get('AWS_REGION', 'ap-southeast-1')

dynamodb = boto3.resource('dynamodb', region_name=AWS_REGION)
conversations_table = dynamodb.Table(CONVERSATIONS_TABLE)
messages_table = dynamodb.Table(MESSAGES_TABLE)
connections_table = dynamodb.Table(CONNECTIONS_TABLE)


def _cors_headers():
    origin = os.environ.get('CHAT_CORS_ORIGIN', '*')
    return {
        'Access-Control-Allow-Origin': origin,
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,OPTIONS'
    }


def _json_default(value):
    if isinstance(value, Decimal):
        return int(value) if value % 1 == 0 else float(value)
    raise TypeError(f'Object of type {type(value)} is not JSON serializable')


def _response(status, body):
    headers = {'Content-Type': 'application/json'}
    headers.update(_cors_headers())
    return {
        'statusCode': status,
        'headers': headers,
        'body': json.dumps(body, default=_json_default)
    }


def _mark_conversation_read(conversation_id, role):
    if not role:
        return

    now = datetime.now(timezone.utc).isoformat()

    # Ensure lastSeenAt map exists
    conversations_table.update_item(
        Key={'conversationId': conversation_id},
        UpdateExpression='SET #ls = if_not_exists(#ls, :empty)',
        ExpressionAttributeNames={'#ls': 'lastSeenAt'},
        ExpressionAttributeValues={':empty': {}}
    )

    conversations_table.update_item(
        Key={'conversationId': conversation_id},
        UpdateExpression='SET #ls.#rr = :t',
        ExpressionAttributeNames={'#ls': 'lastSeenAt', '#rr': role},
        ExpressionAttributeValues={':t': now}
    )

    # Ensure unreadCounts map exists and reset this role
    conversations_table.update_item(
        Key={'conversationId': conversation_id},
        UpdateExpression='SET #uc = if_not_exists(#uc, :empty)',
        ExpressionAttributeNames={'#uc': 'unreadCounts'},
        ExpressionAttributeValues={':empty': {}}
    )

    conversations_table.update_item(
        Key={'conversationId': conversation_id},
        UpdateExpression='SET #uc.#rr = :zero',
        ExpressionAttributeNames={'#uc': 'unreadCounts', '#rr': role},
        ExpressionAttributeValues={':zero': 0}
    )


def _update_conversation_on_message(conversation_id, message_id, text, sender_id, sender_role, recipient_role):
    now = datetime.now(timezone.utc).isoformat()
    expr_names = {
        '#lm': 'lastMessage',
        '#lma': 'lastMessageAt',
        '#lsid': 'lastSenderId',
        '#lsr': 'lastSenderRole',
        '#lmid': 'lastMessageId',
        '#ua': 'updatedAt',
        '#ca': 'createdAt'
    }
    expr_values = {
        ':m': text,
        ':t': now,
        ':sid': sender_id or '',
        ':srole': sender_role or '',
        ':mid': message_id
    }

    update_expr = (
        'SET #ua = :t, #lma = :t, #lm = :m, #lsid = :sid, #lsr = :srole, '
        '#lmid = :mid, #ca = if_not_exists(#ca, :t)'
    )

    conversations_table.update_item(
        Key={'conversationId': conversation_id},
        UpdateExpression=update_expr,
        ExpressionAttributeNames=expr_names,
        ExpressionAttributeValues=expr_values
    )

    if recipient_role:
        try:
            conversations_table.update_item(
                Key={'conversationId': conversation_id},
                UpdateExpression='SET #uc = if_not_exists(#uc, :empty)',
                ExpressionAttributeNames={'#uc': 'unreadCounts'},
                ExpressionAttributeValues={':empty': {}}
            )

            conversations_table.update_item(
                Key={'conversationId': conversation_id},
                UpdateExpression='SET #uc.#rr = if_not_exists(#uc.#rr, :zero) + :one',
                ExpressionAttributeNames={'#uc': 'unreadCounts', '#rr': recipient_role},
                ExpressionAttributeValues={':zero': 0, ':one': 1}
            )
        except Exception as error:
            print('Failed to update unread counts:', error)


def lambda_handler(event, context):
    path = event.get('path', '')
    http_method = event.get('httpMethod', '')
    headers = event.get('headers') or {}

    if http_method == 'OPTIONS':
        return _response(200, {'ok': True})

    auth_header = headers.get('Authorization') or headers.get('authorization')
    token = None
    if auth_header and auth_header.lower().startswith('bearer '):
        token = auth_header.split(' ', 1)[1]

    # Require JWT auth for all REST endpoints
    if not token:
        return _response(401, {'error': 'Missing token'})

    claims = verify_token(token)
    if not claims:
        return _response(401, {'error': 'Invalid token'})

    # Routes:
    # POST /chat/conversations
    if http_method == 'POST' and path.endswith('/chat/conversations'):
        try:
            body = json.loads(event.get('body') or '{}')
            conversation_id = body.get('conversationId')
            application_id = body.get('applicationId')
            participants = body.get('participants') or {}
            mark_read_role = body.get('markReadRole')
            if not conversation_id:
                return _response(400, {'error': 'conversationId required'})

            now = datetime.now(timezone.utc).isoformat()
            update_expr = 'SET createdAt = if_not_exists(createdAt, :now)'
            expr_values = {':now': now}

            if application_id:
                update_expr += ', applicationId = :app'
                expr_values[':app'] = application_id
            if participants:
                update_expr += ', participants = :parts'
                expr_values[':parts'] = participants

            conversations_table.update_item(
                Key={'conversationId': conversation_id},
                UpdateExpression=update_expr,
                ExpressionAttributeValues=expr_values
            )
            if mark_read_role:
                _mark_conversation_read(conversation_id, mark_read_role)

            convo = conversations_table.get_item(Key={'conversationId': conversation_id}).get('Item')
            return _response(200, {'conversationId': conversation_id, 'conversation': convo})
        except Exception as e:
            return _response(500, {'error': str(e)})

    # GET /chat/messages/{conversationId}
    if http_method == 'GET' and '/chat/messages/' in path:
        try:
            convo_id = path.split('/chat/messages/')[-1]
            params = event.get('queryStringParameters') or {}
            limit = int(params.get('limit') or 50)

            # Query messages by conversationId, sort by createdAt desc (assuming createdAt is sort key)
            resp = messages_table.query(
                KeyConditionExpression=Key('conversationId').eq(convo_id),
                Limit=limit,
                ScanIndexForward=False
            )
            items = resp.get('Items', [])
            return _response(200, {'messages': items})
        except Exception as e:
            return _response(500, {'error': str(e)})

    # PUT /chat/messages/{conversationId}
    if http_method == 'PUT' and '/chat/messages/' in path:
        try:
            convo_id = path.split('/chat/messages/')[-1]
            body = json.loads(event.get('body') or '{}')
            message_id = body.get('messageId')
            status = body.get('status')

            if not convo_id or not message_id or not status:
                return _response(400, {'error': 'conversationId, messageId and status required'})

            resp = messages_table.query(KeyConditionExpression=Key('conversationId').eq(convo_id))
            target = next((item for item in resp.get('Items', []) if item.get('messageId') == message_id), None)
            if not target:
                return _response(404, {'error': 'message not found'})

            requester_ids = {
                value for value in [
                    claims.get('sub'),
                    claims.get('cognito:username'),
                    claims.get('username'),
                    claims.get('email')
                ] if value
            }
            if target.get('senderId') not in requester_ids:
                return _response(403, {'error': 'Only the sender can remove this message'})

            key = {'conversationId': convo_id, 'createdAt': target['createdAt']}
            try:
                messages_table.update_item(
                    Key=key,
                    UpdateExpression='SET #status = :status, updatedAt = :updatedAt',
                    ExpressionAttributeNames={'#status': 'status'},
                    ExpressionAttributeValues={
                        ':status': status,
                        ':updatedAt': datetime.now(timezone.utc).isoformat()
                    }
                )
            except Exception:
                messages_table.update_item(
                    Key={'conversationId': convo_id, 'messageId': message_id},
                    UpdateExpression='SET #status = :status, updatedAt = :updatedAt',
                    ExpressionAttributeNames={'#status': 'status'},
                    ExpressionAttributeValues={
                        ':status': status,
                        ':updatedAt': datetime.now(timezone.utc).isoformat()
                    }
                )
            return _response(200, {'conversationId': convo_id, 'messageId': message_id, 'status': status})
        except Exception as e:
            return _response(500, {'error': str(e)})

    # POST /chat/messages
    if http_method == 'POST' and path.endswith('/chat/messages'):
        try:
            body = json.loads(event.get('body') or '{}')
            convo_id = body.get('conversationId')
            text = body.get('text')
            sender_id = body.get('senderId')
            sender_role = body.get('senderRole')
            recipient_role = body.get('recipientRole')

            if not convo_id or not text:
                return _response(400, {'error': 'conversationId and text required'})

            msg_item = {
                'conversationId': convo_id,
                'createdAt': datetime.now(timezone.utc).isoformat(),
                'messageId': body.get('messageId') or f"msg-{int(datetime.now(timezone.utc).timestamp()*1000)}",
                'senderId': sender_id,
                'senderRole': sender_role,
                'text': text,
                'status': 'active'
            }
            if body.get('replyToMessageId'):
                msg_item['replyToMessageId'] = body.get('replyToMessageId')
                msg_item['replyToText'] = body.get('replyToText') or ''
                msg_item['replyToSenderRole'] = body.get('replyToSenderRole') or ''
            messages_table.put_item(Item=msg_item)
            _update_conversation_on_message(
                convo_id,
                msg_item['messageId'],
                text,
                sender_id,
                sender_role,
                recipient_role
            )
            return _response(200, {'messageId': msg_item['messageId']})
        except Exception as e:
            return _response(500, {'error': str(e)})

    return _response(404, {'error': 'Not found'})
